Login Details:
    Email: thatoapple@gmail.com
    Password: Apple/2002

Bonus features that i have implemented:
    1. Added a splashscreen on the app launch.
    2. Created local storage for the API key such that the user does not need 
    to login every time the app is launched. The storage is cleared when the user logs out.